#!/usr/bin/env python3
"""
Eboard Bridge - Proceso intermedio de 32-bit para comunicación con drivers de tableros digitales
Este script debe ejecutarse con Python 32-bit
"""
import ctypes
import json
import sys
import os
import time
from typing import Optional, Dict, Any

class EboardBridge:
    def __init__(self):
        self.name = None
        self.driver = None
        self.setup = False
        self.fen_eboard = None
        self.dispatch_queue = []
        self.callbacks = {}
        
    def load_driver(self, board_name: str, dll_path: str) -> Dict[str, Any]:
        """Cargar el driver del tablero digital"""
        try:
            self.name = board_name
            
            if not os.path.isfile(dll_path):
                return {"success": False, "error": f"DLL not found: {dll_path}"}
            
            # Cargar la DLL de 32-bit
            self.driver = ctypes.WinDLL(dll_path)
            
            # Configurar las funciones del driver
            self._setup_driver_functions()
            
            return {"success": True, "message": f"Driver {board_name} loaded successfully"}
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def _setup_driver_functions(self):
        """Configurar las funciones del driver"""
        if not self.driver:
            return
            
        # Definir tipos de función
        functype = ctypes.WINFUNCTYPE
        
        # Configurar funciones de callback
        self._setup_callbacks(functype)
        
        # Configurar funciones del driver
        self._setup_driver_methods()
        
    def _setup_callbacks(self, functype):
        """Configurar callbacks del driver"""
        # Status callback
        cmpfunc = functype(ctypes.c_int, ctypes.c_char_p)
        status_callback = cmpfunc(self._register_status_func)
        self.driver._DGTDLL_RegisterStatusFunc.argtype = [status_callback]
        self.driver._DGTDLL_RegisterStatusFunc.restype = ctypes.c_int
        self.driver._DGTDLL_RegisterStatusFunc(status_callback)
        
        # Scan callback
        scan_callback = cmpfunc(self._register_scan_func)
        self.driver._DGTDLL_RegisterScanFunc.argtype = [scan_callback]
        self.driver._DGTDLL_RegisterScanFunc.restype = ctypes.c_int
        self.driver._DGTDLL_RegisterScanFunc(scan_callback)
        
        # Setup callbacks
        setup_callback = functype(ctypes.c_int)
        start_setup = setup_callback(self._register_start_setup_func)
        self.driver._DGTDLL_RegisterStartSetupFunc.argtype = [start_setup]
        self.driver._DGTDLL_RegisterStartSetupFunc.restype = ctypes.c_int
        self.driver._DGTDLL_RegisterStartSetupFunc(start_setup)
        
        # Stable board callback
        stable_callback = cmpfunc(self._register_stable_board_func)
        self.driver._DGTDLL_RegisterStableBoardFunc.argtype = [stable_callback]
        self.driver._DGTDLL_RegisterStableBoardFunc.restype = ctypes.c_int
        self.driver._DGTDLL_RegisterStableBoardFunc(stable_callback)
        
        # Move callbacks
        white_move = cmpfunc(self._register_white_move_func)
        self.driver._DGTDLL_RegisterWhiteMoveInputFunc.argtype = [white_move]
        self.driver._DGTDLL_RegisterWhiteMoveInputFunc.restype = ctypes.c_int
        self.driver._DGTDLL_RegisterWhiteMoveInputFunc(white_move)
        
        black_move = cmpfunc(self._register_black_move_func)
        self.driver._DGTDLL_RegisterBlackMoveInputFunc.argtype = [black_move]
        self.driver._DGTDLL_RegisterBlackMoveInputFunc.restype = ctypes.c_int
        self.driver._DGTDLL_RegisterBlackMoveInputFunc(black_move)
        
    def _setup_driver_methods(self):
        """Configurar métodos del driver"""
        self.driver._DGTDLL_WritePosition.argtype = [ctypes.c_char_p]
        self.driver._DGTDLL_WritePosition.restype = ctypes.c_int
        
        self.driver._DGTDLL_ShowDialog.argtype = [ctypes.c_int]
        self.driver._DGTDLL_ShowDialog.restype = ctypes.c_int
        
        self.driver._DGTDLL_HideDialog.argtype = [ctypes.c_int]
        self.driver._DGTDLL_HideDialog.restype = ctypes.c_int
        
        self.driver._DGTDLL_SetNRun.argtype = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int]
        self.driver._DGTDLL_SetNRun.restype = ctypes.c_int
        
    def _register_status_func(self, dato):
        """Callback para status"""
        self._send_to_main("status", dato.decode() if dato else "")
        return 1
        
    def _register_scan_func(self, dato):
        """Callback para scan"""
        fen = self._dgt2fen(dato)
        self._send_to_main("scan", fen)
        return 1
        
    def _register_start_setup_func(self):
        """Callback para inicio de setup"""
        self.setup = True
        self._send_to_main("startSetup", "")
        return 1
        
    def _register_stable_board_func(self, dato):
        """Callback para tablero estable"""
        self.fen_eboard = self._dgt2fen(dato)
        if self.setup:
            self._send_to_main("stableBoard", self.fen_eboard)
        return 1
        
    def _register_white_move_func(self, dato):
        """Callback para movimiento blanco"""
        pv = self._dgt2pv(dato)
        self._send_to_main("whiteMove", pv)
        return 1
        
    def _register_black_move_func(self, dato):
        """Callback para movimiento negro"""
        pv = self._dgt2pv(dato)
        self._send_to_main("blackMove", pv)
        return 1
        
    def _send_to_main(self, event_type: str, data: str):
        """Enviar evento al proceso principal"""
        message = {
            "type": "event",
            "event": event_type,
            "data": data,
            "timestamp": time.time()
        }
        print(json.dumps(message), flush=True)
        
    def write_position(self, position: str) -> Dict[str, Any]:
        """Escribir posición en el tablero"""
        try:
            if self.driver and position != self.fen_eboard:
                result = self.driver._DGTDLL_WritePosition(position.encode())
                self.fen_eboard = position
                return {"success": True, "result": result}
            return {"success": False, "error": "Driver not loaded"}
        except Exception as e:
            return {"success": False, "error": str(e)}
            
    def show_dialog(self, show: bool = True) -> Dict[str, Any]:
        """Mostrar/ocultar diálogo"""
        try:
            if self.driver:
                result = self.driver._DGTDLL_ShowDialog(ctypes.c_int(1 if show else 0))
                return {"success": True, "result": result}
            return {"success": False, "error": "Driver not loaded"}
        except Exception as e:
            return {"success": False, "error": str(e)}
            
    def write_clocks(self, wclock: str, bclock: str) -> Dict[str, Any]:
        """Escribir relojes"""
        try:
            if self.driver and self.name in ("DGT", "DGT-gon"):
                result = self.driver._DGTDLL_SetNRun(wclock.encode(), bclock.encode(), 0)
                return {"success": True, "result": result}
            return {"success": False, "error": "Driver not loaded or not supported"}
        except Exception as e:
            return {"success": False, "error": str(e)}
            
    def deactivate(self) -> Dict[str, Any]:
        """Desactivar driver"""
        try:
            if self.driver:
                self.driver._DGTDLL_HideDialog(ctypes.c_int(1))
                handle = self.driver._handle
                ctypes.windll.kernel32.FreeLibrary(handle)
                del self.driver
                self.driver = None
            return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}
            
    @staticmethod
    def _dgt2fen(datobyte) -> str:
        """Convertir datos DGT a FEN"""
        n = 0
        dato = datobyte.decode()
        ndato = len(dato)
        caja = [""] * 8
        ncaja = 0
        ntam = 0
        while True:
            if dato[n].isdigit():
                num = int(dato[n])
                if (n + 1 < ndato) and dato[n + 1].isdigit():
                    num = num * 10 + int(dato[n + 1])
                    n += 1
                while num:
                    pte = 8 - ntam
                    if num >= pte:
                        caja[ncaja] += str(pte)
                        ncaja += 1
                        ntam = 0
                        num -= pte
                    else:
                        caja[ncaja] += str(num)
                        ntam += num
                        break
            else:
                caja[ncaja] += dato[n]
                ntam += 1
            if ntam == 8:
                ncaja += 1
                ntam = 0
            n += 1
            if n == ndato:
                break
        if ncaja != 8:
            caja[7] += str(8 - ntam)
        return "/".join(caja)
        
    @staticmethod
    def _dgt2pv(datobyte) -> str:
        """Convertir datos DGT a PV"""
        dato = datobyte.decode()
        # Coronación
        if dato[0] in "Pp" and dato[3].lower() != "p":
            return dato[1:3] + dato[4:6] + dato[3].lower()
        return dato[1:3] + dato[4:6]

def main():
    """Función principal del bridge"""
    bridge = EboardBridge()
    
    try:
        # Leer comandos desde stdin
        for line in sys.stdin:
            try:
                command = json.loads(line.strip())
                response = {"id": command.get("id")}
                
                action = command.get("action")
                params = command.get("params", {})
                
                if action == "load_driver":
                    result = bridge.load_driver(
                        params.get("board_name"), 
                        params.get("dll_path")
                    )
                    response.update(result)
                    
                elif action == "write_position":
                    result = bridge.write_position(params.get("position", ""))
                    response.update(result)
                    
                elif action == "show_dialog":
                    result = bridge.show_dialog(params.get("show", True))
                    response.update(result)
                    
                elif action == "write_clocks":
                    result = bridge.write_clocks(
                        params.get("wclock", ""), 
                        params.get("bclock", "")
                    )
                    response.update(result)
                    
                elif action == "deactivate":
                    result = bridge.deactivate()
                    response.update(result)
                    
                elif action == "quit":
                    bridge.deactivate()
                    response["success"] = True
                    print(json.dumps(response), flush=True)
                    break
                    
                else:
                    response["success"] = False
                    response["error"] = f"Unknown action: {action}"
                
                print(json.dumps(response), flush=True)
                
            except json.JSONDecodeError:
                print(json.dumps({"success": False, "error": "Invalid JSON"}), flush=True)
            except Exception as e:
                print(json.dumps({"success": False, "error": str(e)}), flush=True)
                
    except KeyboardInterrupt:
        bridge.deactivate()
    except Exception as e:
        print(json.dumps({"success": False, "error": f"Bridge error: {str(e)}"}), flush=True)

if __name__ == "__main__":
    main()
