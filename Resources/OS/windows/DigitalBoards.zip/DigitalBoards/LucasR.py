from PySide6.QtWidgets import QApplication
from eboard_driverhost import EboardDriverHostQProcess

from PySide6.QtCore import QProcess, QTimer

def handle_event(name, data):
    print(f"[EVENT] {name}: {data}")


app = QApplication([])

eb = EboardDriverHostQProcess(r".\MCL_DLL.dll")
eb.set_dispatch(handle_event)

QTimer.singleShot(200, eb.init_driver)

# Ejemplo de comandos
eb.show_dialog()
eb.set_position("8/8/8/8/8/8/8/8")
eb.write_clocks("00:05", "00:10")
eb.show_dialog()

app.exec()
