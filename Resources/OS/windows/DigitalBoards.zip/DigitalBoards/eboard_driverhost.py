import json
import socket
import threading
import time

from PySide6.QtCore import QProcess, QTimer


class EboardDriverHostQProcess:
    """
    Wrapper Eboard que:
    - Lanza driverhost_full.exe automáticamente con QProcess
    - Se comunica vía socket JSON
    - Maneja todos los eventos y comandos
    """

    def __init__(self, dll_path, host="127.0.0.1", port=8765):
        self.dll_path = dll_path
        self.host = host
        self.port = port
        self.sock = None
        self.dispatch = None
        self.fen_eboard = None
        self.setup = False
        self.working_time = None
        self.running = False

        # =====================
        # Lanzar driverhost_full.exe
        # =====================
        self.proc = QProcess()
        self.proc.started.connect(lambda: print("DriverHost iniciado"))
        self.proc.finished.connect(lambda code, status: print(f"DriverHost terminó ({code})"))

        self.proc.start("driverhost32.exe", [dll_path])

        # =====================
        # Thread de socket TCP
        # =====================
        self.thread = threading.Thread(target=self._socket_thread, daemon=True)
        self.thread.start()

    def init_driver(self):
        self.show_dialog()
        self.set_position("8/8/8/8/8/8/8/8")

    def _connect(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        while True:
            try:
                self.sock.connect((self.host, self.port))
                break
            except ConnectionRefusedError:
                time.sleep(0.1)
        self.running = True

    # =====================
    # Thread de lectura de eventos
    # =====================
    def _socket_thread(self):
        self._connect()
        buffer = b""
        while True:
            try:
                data = self.sock.recv(4096)
                if not data:
                    break
                buffer += data
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    if line.strip():
                        self._handle_event(json.loads(line.decode()))
            except Exception:
                break
        self.running = False

    # =====================
    # Manejar evento JSON
    # =====================
    def _handle_event(self, event):
        name = event.get("name")
        data = event.get("data")
        if name == "stableBoard":
            self.fen_eboard = data
            if self.setup and self.dispatch:
                self.dispatch("stableBoard", data)
        elif name in ("whiteMove", "blackMove", "whiteTakeback", "blackTakeback", "scan", "status"):
            if self.dispatch:
                self.dispatch(name, data)
        elif name in ("startSetup", "stopSetupWTM", "stopSetupBTM"):
            self.setup = name == "startSetup"
            if self.dispatch:
                self.dispatch(name, data)
        elif name == "error":
            print(f"[EBOARD ERROR] {data}")

    # =====================
    # API pública
    # =====================
    def set_dispatch(self, dispatch):
        self.dispatch = dispatch

    def is_working(self):
        return self.working_time is not None and 1.0 > (time.time() - self.working_time)

    def set_working(self):
        self.working_time = time.time()

    def set_position(self, position_fen):
        if position_fen != self.fen_eboard:
            self.send_command("write_position", position_fen)
            self.fen_eboard = position_fen

    def write_clocks(self, wclock, bclock):
        self.send_command("write_clocks", json.dumps({"w": wclock, "b": bclock}))

    def show_dialog(self):
        self.send_command("show_dialog")

    def hide_dialog(self):
        self.send_command("hide_dialog")

    def write_debug(self, activar: bool):
        self.send_command("write_debug", "true" if activar else "false")

    # def send_command(self, name, data=""):
    #     self._connect()
    #     cmd = {"type":"cmd","name":name,"data":data}
    #     self.sock.sendall((json.dumps(cmd)+"\n").encode())

    def send_command(self, name, data=""):
        if not self.running or not self.sock:
            return
        cmd = {"type": "cmd", "name": name, "data": data}
        self.sock.sendall((json.dumps(cmd) + "\n").encode())
