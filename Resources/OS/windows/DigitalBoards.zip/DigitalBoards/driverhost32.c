// build: gcc -m32 driverhost_full.c -lws2_32 -lshlwapi -o driverhost.exe
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winsock2.h>
#include <shlwapi.h>
#include <stdio.h>

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "shlwapi.lib")

// ========================
// DLL ABI
// ========================
typedef int (__stdcall *CB_CHAR)(const char *);
typedef int (__stdcall *CB_VOID)(void);
typedef int (__stdcall *CB_BOOL)(int);

typedef int (__stdcall *REG_SCAN)(CB_CHAR);
typedef int (__stdcall *REG_STATUS)(CB_CHAR);
typedef int (__stdcall *REG_START_SETUP)(CB_VOID);
typedef int (__stdcall *REG_STABLE)(CB_CHAR);
typedef int (__stdcall *REG_STOPWTM)(CB_CHAR);
typedef int (__stdcall *REG_STOPBTM)(CB_CHAR);
typedef int (__stdcall *REG_WHITE_MOVE)(CB_CHAR);
typedef int (__stdcall *REG_BLACK_MOVE)(CB_CHAR);
typedef int (__stdcall *REG_WHITE_TB)(CB_VOID);
typedef int (__stdcall *REG_BLACK_TB)(CB_VOID);

typedef int (__stdcall *WRITE_POS)(const char *);
typedef int (__stdcall *WRITE_CLOCKS)(const char *, const char *, int);
typedef int (__stdcall *SHOW_DIALOG)(int);
typedef int (__stdcall *HIDE_DIALOG)(int);
typedef int (__stdcall *WRITE_DEBUG)(int);

// ========================
// Globals
// ========================
static SOCKET g_client = INVALID_SOCKET;

// ========================
// IPC
// ========================
void send_event(const char *name, const char *data){
    if(g_client == INVALID_SOCKET) return;
    char buf[1024];
    snprintf(buf,sizeof(buf),
        "{\"type\":\"event\",\"name\":\"%s\",\"data\":\"%s\"}\n",
        name, data ? data : "");
    send(g_client,buf,(int)strlen(buf),0);
}

// ========================
// Callbacks
// ========================
int __stdcall cb_scan(const char *d){ send_event("scan",d); return 1; }
int __stdcall cb_status(const char *d){ send_event("status",d); return 1; }
int __stdcall cb_start_setup(void){ send_event("startSetup",""); return 1; }
int __stdcall cb_stable(const char *d){ send_event("stableBoard",d); return 1; }
int __stdcall cb_stop_wtm(const char *d){ send_event("stopSetupWTM",d); return 1; }
int __stdcall cb_stop_btm(const char *d){ send_event("stopSetupBTM",d); return 1; }
int __stdcall cb_white_move(const char *d){ send_event("whiteMove",d); return 1; }
int __stdcall cb_black_move(const char *d){ send_event("blackMove",d); return 1; }
int __stdcall cb_white_tb(void){ send_event("whiteTakeback",""); return 1; }
int __stdcall cb_black_tb(void){ send_event("blackTakeback",""); return 1; }

// ========================
// IPC Server
// ========================
SOCKET wait_gui(void){
    WSADATA wsa; SOCKET s; struct sockaddr_in addr;
    WSAStartup(MAKEWORD(2,2),&wsa);
    s=socket(AF_INET,SOCK_STREAM,0);
    addr.sin_family=AF_INET; addr.sin_port=htons(8765); addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bind(s,(struct sockaddr*)&addr,sizeof(addr));
    listen(s,1);
    printf("Waiting GUI...\n");
    return accept(s,NULL,NULL);
}

// ========================
// Main
// ========================
int main(int argc,char **argv){
    if(argc<2){ printf("Usage: driverhost32.exe <path_to_dll>\n"); return 1; }
    const char *dll_path = argv[1];
    HMODULE dll;

    g_client = wait_gui();
    printf("GUI connected\n");

    char dll_dir[MAX_PATH]; GetFullPathNameA(dll_path,MAX_PATH,dll_dir,NULL); PathRemoveFileSpecA(dll_dir);
    SetCurrentDirectoryA(dll_dir);

    dll = LoadLibraryA(dll_path);
    if(!dll){ send_event("error","Cannot load DLL"); return 2; }

    // ===== Register callbacks =====
    REG_SCAN reg_scan = (REG_SCAN)GetProcAddress(dll,"_DGTDLL_RegisterScanFunc");
    REG_STATUS reg_status = (REG_STATUS)GetProcAddress(dll,"_DGTDLL_RegisterStatusFunc");
    REG_START_SETUP reg_setup = (REG_START_SETUP)GetProcAddress(dll,"_DGTDLL_RegisterStartSetupFunc");
    REG_STABLE reg_stable = (REG_STABLE)GetProcAddress(dll,"_DGTDLL_RegisterStableBoardFunc");
    REG_STOPWTM reg_stop_wtm = (REG_STOPWTM)GetProcAddress(dll,"_DGTDLL_RegisterStopSetupWTMFunc");
    REG_STOPBTM reg_stop_btm = (REG_STOPBTM)GetProcAddress(dll,"_DGTDLL_RegisterStopSetupBTMFunc");
    REG_WHITE_MOVE reg_wmove = (REG_WHITE_MOVE)GetProcAddress(dll,"_DGTDLL_RegisterWhiteMoveInputFunc");
    REG_BLACK_MOVE reg_bmove = (REG_BLACK_MOVE)GetProcAddress(dll,"_DGTDLL_RegisterBlackMoveInputFunc");
    REG_WHITE_TB reg_wtb = (REG_WHITE_TB)GetProcAddress(dll,"_DGTDLL_RegisterWhiteTakebackFunc");
    REG_BLACK_TB reg_btb = (REG_BLACK_TB)GetProcAddress(dll,"_DGTDLL_RegisterBlackTakebackFunc");

    WRITE_POS write_pos = (WRITE_POS)GetProcAddress(dll,"_DGTDLL_WritePosition");
    WRITE_CLOCKS write_clocks = (WRITE_CLOCKS)GetProcAddress(dll,"_DGTDLL_SetNRun");
    SHOW_DIALOG show_dialog = (SHOW_DIALOG)GetProcAddress(dll,"_DGTDLL_ShowDialog");
    HIDE_DIALOG hide_dialog = (HIDE_DIALOG)GetProcAddress(dll,"_DGTDLL_HideDialog");
    WRITE_DEBUG write_debug = (WRITE_DEBUG)GetProcAddress(dll,"_DGTDLL_WriteDebug");

    if(reg_scan) reg_scan(cb_scan);
    if(reg_status) reg_status(cb_status);
    if(reg_setup) reg_setup(cb_start_setup);
    if(reg_stable) reg_stable(cb_stable);
    if(reg_stop_wtm) reg_stop_wtm(cb_stop_wtm);
    if(reg_stop_btm) reg_stop_btm(cb_stop_btm);
    if(reg_wmove) reg_wmove(cb_white_move);
    if(reg_bmove) reg_bmove(cb_black_move);
    if(reg_wtb) reg_wtb(cb_white_tb);
    if(reg_btb) reg_btb(cb_black_tb);
    if(show_dialog) show_dialog(1);

    // ===== Command loop =====
    char buf[1024];
    while(1){
        int n=recv(g_client,buf,sizeof(buf)-1,0);
        if(n<=0) break;
        buf[n]=0;

        // write_position
        if(strstr(buf,"\"write_position\"")){
            char *p=strstr(buf,"\"data\":\"");
            if(p){ p+=8; char *e=strchr(p,'"'); if(e){*e=0; write_pos(p); } }
        }
        // write_clocks
        else if(strstr(buf,"\"write_clocks\"")){
            char *p=strstr(buf,"\"w\":\""); char *q=strstr(buf,"\"b\":\"");
            if(p && q){ p+=5; q+=5; char *ep=strchr(p,'"'); char *eq=strchr(q,'"'); if(ep && eq){*ep=0; *eq=0; write_clocks(p,q,0); } }
        }
        // show_dialog
        else if(strstr(buf,"\"show_dialog\"") && show_dialog){ show_dialog(1); }
        // hide_dialog
        else if(strstr(buf,"\"hide_dialog\"") && hide_dialog){ hide_dialog(1); }
        // write_debug
        else if(strstr(buf,"\"write_debug\"") && write_debug){
            int val = strstr(buf,"true")?1:0;
            write_debug(val);
        }
    }

    FreeLibrary(dll);
    closesocket(g_client);
    WSACleanup();
    return 0;
}
