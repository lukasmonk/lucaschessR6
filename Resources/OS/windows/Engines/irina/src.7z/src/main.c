#include "protos.h"

int main() {
    begin();

    loop();

    return 0;
}
