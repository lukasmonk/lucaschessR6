#ifndef IRINA_HASH_H
#define IRINA_HASH_H

typedef struct
{
   Bitmap   hashkey;
   int      val;
} HASH_reg;

#endif
