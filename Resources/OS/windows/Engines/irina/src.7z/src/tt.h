#ifndef TT_H
#define TT_H

#define NO_TT_HIT 20000 // Valor de puntuaci�n que indica que no hubo un 'hit' de corte

// Flags para el tipo de entrada
#define FLAG_EXACT 0
#define FLAG_LOWERBOUND 1
#define FLAG_UPPERBOUND 2

typedef struct TtEntry
{
    Bitmap hashKey; // Hash Zobrist completo (para verificar colisiones)
    Move bestMove;  // El mejor movimiento de esta posici�n (Hash Move)
    int score;      // Puntuaci�n de la posici�n
    int depth;      // Profundidad restante a la que se busc�
    int flag;       // Tipo de puntuaci�n (Exact, Lowerbound, Upperbound)
} TtEntry;

// Variable global para la tabla
extern TtEntry *ttTable;

void init_ttTable(int max_mb);
void set_hash_ttTable(char * value);
int probeEntry(Bitmap hashKey, int depth, int alpha, int beta, Move* bestMove);
void storeEntry(Bitmap hashKey, int score, int depth, int flag, Move bestMove);

#endif // TT_H
